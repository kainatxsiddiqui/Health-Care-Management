
import java.util.Scanner;

//THREAD SYNCHRONIZATION//
public class TestThread {
     private String s;  
    TestThread(String s) {  
    this.s = s;  
    }  
    public String getName() {  
    return s;  
    }  
    public void setName(String coursename) {  
    this.s = coursename;  
    }  

   public static void main(String args[]) {
       Scanner sc = new Scanner(System.in);
       ///////////////MUTABILITY//////
      TestThread obj = new TestThread("===WELCOME TO HEALTHCARE SYSTEM");  
    System.out.println(obj.getName());  
// Here, we can update the name using the setName method.  
    obj.setName(".............................");  
    System.out.println(obj.getName());
    
    
    /////////////////////////my code//////
    
    
    
   
    System.out.print("Enter your Name :");
    String a = sc.next();
    System.out.print("Enter your Age :");
    String b=sc.next();
    System.out.print("Enter your Gender :");
    String g=sc.next();
    System.out.print("Address your issue :");
    String c = sc.next();
    System.out.println("=========================");
    System.out.println("Following are the Doctors available");
    System.out.println("Dr.Arina Fatima");
    System.out.println("Dr.Kainat Siddique");
    System.out.println("Dr.Shiza Majid");
    System.out.println("=========================");
    System.out.println("Whom you want to consult?");
    System.out.print("Enter Doctor's Name:");
    String d = sc.next();
    System.out.println("The Fees of above doctor is 2000");
    System.out.println("Do you wnt to make it confirm?");
    String f = sc.next();
    
    
    
    
     ////////////IMMUTABILITY//////////////////////
     System.out.println("========================="); 
    System.out.println("Kindly do your payment via easypaisa");
        StudentImmutableClass student1 = new StudentImmutableClass(2000, "dany");
        System.out.println("your current payment : " + student1.getPayment());
        System.out.println("Confirm Payement: " + student1.getPayment());
        System.out.println("=========================");
        System.out.println("====Now how multiple patients will work through thread synchronization====");
    
  
    
   

      
//////////////////////////SYNCHRONIZATION/////////////////////
       
      PrintDemo PD = new PrintDemo();

      ThreadDemo T1 = new ThreadDemo( "1 ", PD );
      ThreadDemo T2 = new ThreadDemo( "2 ", PD );

      T1.start();
      T2.start();

      // wait for threads to end
      try {
         T1.join();
         T2.join();
      } catch ( Exception e) {
         System.out.println("patient Interrupted");
      }
      ////////////IMMUTABILITY//////////////////////
       

      
      
   }
}
////////////////////////////////
