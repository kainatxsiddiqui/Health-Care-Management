
//THREAD SYNCHRONIZATION//
class PrintDemo {
   public void printCount() {
      try {
         for(int i = 2; i > 0; i--) {
            System.out.println("Order of patients according to thread synchronization   ---   "  + i );
         }
      } catch (Exception e) {
         System.out.println("Patients consultation is  interrupted.");
      }
   }
}