//IMMUTABLE//
final class StudentImmutableClass {
     private final int payment;
    private final String name;

    public StudentImmutableClass(int payment , String name) {
        this.payment = payment;
        this.name = name;
    }
    public int getPayment() {
        return payment;
    }
    public String getName() {
        return name;
    }
}
   